# Changelog

### v 0.0.6 (1/17/14)

- added resume method
- format startVal on initialization

### v 0.0.5 (1/17/14)

- added stop method
- fixed reset method
- improved demo to include stop, reset, callback and code visualization

### v 0.0.4 (1/16/14)

- added callback thanks to @retasretas
- added requestAnimationFrame() polyfill to support IE8 and other browsers without native rAF support

### v 0.0.3 (1/13/14)

- added startVal param
- ability to count in either direction
- ability to toggle easing
- added minified version thanks to @HHSnopek

### v 0.0.2 (1/13/14)

- coffeescript version added thanks to @HHSnopek
- bower & component support
- changelog added
- bug fixes and improvements thanks to @lifthrasiir

### v 0.0.1 (12/31/13)

- initial release
