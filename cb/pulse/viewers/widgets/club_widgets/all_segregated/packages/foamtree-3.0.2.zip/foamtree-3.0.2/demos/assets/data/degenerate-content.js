modelDataAvailable({"groups":[
  {"label":"amp: & lt: < gt: > backu0123: \\u0123 backback: \\\\", "weight":0, "groups":[
    {"label":"group00.01", "weight":0, "id":"1"},
    {"label":"group00.02", "weight":0, "groups":[
      {"label":"group00.03", "weight":0, "id":"3"}
    ], "id":"2"}
  ], "id":"0"}
]});