modelDataAvailable({"groups":[
  {"label":"الرئيسية", "weight":1, "id":"0"},
  {"label":"ABCDEF abcdef 01234 .,;", "weight":1, "id":"1"},
  {"label":"ęółśążźćń ĘÓŁŚĄŻŹĆŃ", "weight":1, "id":"2"},
  {"label":"æ å Æ ø Å ä ü Weißenkirchen", "weight":1, "id":"3"},
  {"label":"請以手足關係的精神相對待。, 请以手足关系的精神相对待", "weight":1, "id":"4"},
  {"label":"형제애의 정신으로 행동하여야 한다.", "weight":1, "id":"5"},
  {"label":"互いに同胞の精神をもって行動しなければならない。", "weight":1, "id":"6"},
  {"label":"עברית", "weight":1, "id":"7"},
  {"label":"ייִדיש", "weight":1, "id":"8"}
]});